import {environment} from './environments/environment';
export class Configuration {

  public APIUrl1 = environment.serverUrl +'/api';

  // Team Settings and User Create
  public authorizeAPI = this.APIUrl1 + "/login";
  

}
