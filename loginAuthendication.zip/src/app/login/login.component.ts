import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {LoginServiceService} from './login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // model: ILogin = { userid: "admin", password: "admin123" };
  loginForm: FormGroup;
  message: any;
  returnUrl: string;
  userid : any;
  password: any;
  submitted : false;
  data:{};

  constructor(private formBuilder: FormBuilder, private loginServiceService: LoginServiceService,
    private router: Router,) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['',[ Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
    this.returnUrl = '/dashboard';
    // this.authService.logout();
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  
  login() {
    debugger;
    submitted : true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    else{
      const inputParameter = {
        email : this.loginForm.value.email,
        password : this.loginForm.value.password,

      }
      this.loginServiceService.authorizeUser(inputParameter).subscribe(
        (result : any)=>{
        
          console.log(result);
          if (result) {
            this.router.navigate([this.returnUrl]);
          }

      });
      }
 
};

}