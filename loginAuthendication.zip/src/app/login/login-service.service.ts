import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Configuration} from '../../config';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  
  readonly httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  // config: any;

  constructor(private http: HttpClient, private config: Configuration,) { }

  public authorizeUser = (userRequest: any)=>{
    debugger;
    return this.http.post(this.config.authorizeAPI, userRequest, this.httpOptions);
  
  }

  // public requestPasswordService = (userRequest: any)=>{

  //   return this.http.post(this.config.forgetpasswordAPI, userRequest, this.httpOptions);
  
  // }


}
