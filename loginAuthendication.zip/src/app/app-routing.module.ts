import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { TableComponent } from './dashboard/table/table.component';

const routes: Routes = [

  { path: '', redirectTo: 'login', pathMatch: 'full', },
  { path: 'dashboard', component:  DashboardComponent,}, 
  { path: 'login', component:  LoginComponent,},
  { path: 'table', component:  TableComponent,},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
